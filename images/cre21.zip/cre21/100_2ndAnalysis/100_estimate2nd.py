#!/usr/bin/env python
# coding: utf-8

import re, os
from collections import OrderedDict
import subprocess


#########################################

dataset = "Exc3rd"
#dataset = "Inc3rd"
#dataset = "prot"

num_pthred_raxml = 8 # 2

#########################################


top = '''
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html">
        <title>CNS_alignent</title>
            <style type="text/css">
                .blackBG { background-color: #000000; color: white}
                .redBG { background-color: #FF0000; color: white}
            </style>
    </head>
<body>
<pre>
<span style="font-size: 130%;">'''

bottom = '''
</span></pre>
</body>
</html>'''


### Functions

def deleteGap_fasFile(cDNAfasFileName):
    recsFN = readFasta_dict(cDNAfasFileName)
    recsFN = delete_gap(recsFN)
    fa = open("110_noGapFas.txt","w")
    for name, seq in recsFN.items():
        fa.write(name + "\n")
        fa.write(seq + "\n")
    fa.close()

def readFasta_dict(InfileNameFN):
    Infile = open(InfileNameFN, "r")
    seqDictFN  = OrderedDict()
    for Line in Infile:
        #print(Line)
        Line = Line.rstrip("\n")
        if not Line:
            continue
        elif Line[0] == ">":
            Name            = Line
            seqDictFN[Name] = ""
        else:
            Line = Line.replace("\n", "")
            Line = Line.replace("\r", "")
            #seqDictFN[Name] += Line.upper()
            seqDictFN[Name] += Line
    Infile.close()
    return seqDictFN

def delete_gap(recsFN):
    recsFN1        = OrderedDict()
    for name, seq in recsFN.items():
        seq = re.sub("-", "", seq)
        recsFN1[name] = seq
    return recsFN1

def fas2phy(fasFileName, outfile):
    recsFN = readFasta_dict(fasFileName)
    recsFN = delete_nameSpaceSeqBp(recsFN)
    orderedDict2phyFile(recsFN, outfile)

def delete_nameSpaceSeqBp(recsFN):
    recsFN2        = OrderedDict()
    for name, seq in recsFN.items():
        if re.search(" \d+ bp$", name):
            name = re.sub(" \d+ bp$", "", name)
        recsFN2[name] = seq
    return recsFN2

def orderedDict2phyFile(recs, outfile):
    secLength     = len(sorted(recs.values())[0])
    spSeqSizeLine = str(len(recs)) + " " + str(secLength)

    recs = whiteSpaceAdd(recs)
    out  = open(outfile, "w")
    out.write(spSeqSizeLine + "\n")
    for name,value in recs.items():
        out.write(name + value + "\n")
    out.close()

def whiteSpaceAdd(recsFN1):
    longestName = max(recsFN1.keys(), key = len)
    longestName = re.sub("<[^>]+>", "", longestName)
    longestNameLen = len(longestName)
    recsFN2        = OrderedDict()
    for name,value in recsFN1.items():
        nameTMP = re.sub("<[^>]+>", "", name)
        nameWhiteSpace = name[1:] + " " * (longestNameLen - len(nameTMP) + 2)
        recsFN2[nameWhiteSpace] = value
    return recsFN2

def trimaledPhyMake(fastaFile):
    recs = readFasta_dict(fastaFile)
    recsTrimed = OrderedDict()
    for name,sequence in recs.items():
        name1 = re.sub(" >*", "", name)
        recsTrimed[name1] = sequence
    orderedDict2phyFile(recsTrimed, outfile = "150_trimedPhy.txt")

def outGroupSelect (phyFileName):
    recSeqFN = readPhy_dict(phyFileName)
    outgroupTMP = list(recSeqFN.keys())[0]
    return outgroupTMP[1:]

def readPhy_dict(phyFileName):
    phyFile = open(phyFileName, "r")
    lines = list(phyFile)
    seqDictFN  = OrderedDict()
    for line in lines[1:]:
        #print("line:", line)
        name,seq = re.split(" +", line)
        #print("seq:", seq) 
        seq = seq.rstrip("\n")
        seqDictFN[">" + name] = seq
    phyFile.close()
    return seqDictFN

def remove_files2():
    subprocess.call("rm 110_noGapFas.txt", shell=True)
    subprocess.call("rm 120_mafOutFas.txt", shell=True)
    subprocess.call("rm 130_trimedOut.html", shell=True)
    subprocess.call("rm 130_trimedOutFas.txt", shell=True)
    subprocess.call("rm 150_trimedPhy.txt", shell=True)

def firstSpeciesPicker(recsFN):
    #record_1st = list(recsFN.items())[0]
    record_1st = list(recsFN.items())[-1]
    name_1st = record_1st[0]
    seq_1st = record_1st[1]
    #print("name_1st", name_1st)
    #print("seq_1st", seq_1st)
    return name_1st, seq_1st

def addSiteNotes(inFileAAFN, recsFN):
    seqDictFN  = OrderedDict()
    sequence_tm = trimAlresReader(inFileAAFN)
    seqDictFN[">Used4treeSearch"] = sequence_tm
    for name, value in recsFN.items():
      seqDictFN[name] = value
    return seqDictFN

def make_species_color(summaryFile):
    Infile = open(summaryFile, "r")
    species_color_FN = OrderedDict()
    flag = 0
    for line in Infile:
        if flag == 1:
            if line[0] == ">":
                break
            #if re.search("([^ ]+) +([^ ]+)", line):
            #    match = re.search("([^ ]+) +([^ ]+)", line)
            if re.search("^[^_]+_[^_]+$", line):
                match = re.search("^([^_]+)_([^_]+)$", line)
                species = match.group(1)
                color = match.group(2)
                species_color_FN[species] = color
        if re.search(">taxonSampling_color", line):
            flag = 1
    return species_color_FN


def matchFirst_eachCharacter (keyNameFN, keySpcharacterFN, nameFN, characterFN):
    #print("keyNameFN", keyNameFN, "<br>")
    #print("keySpcharacterFN", keySpcharacterFN, "<br>")
    #print("nameFN", nameFN, "<br>")
    #print("characterFN", keySpcharacterFN, "<br>")
    #print("<br>")
    #exit()
    characterFN_mod = ""
    nameFN = ">" + nameFN
    
    if keyNameFN[1:] in nameFN:
        #print("keyNameFN", keyNameFN, "<br>")
        #print("keySpcharacterFN", keySpcharacterFN, "<br>")
        #print("nameFN", nameFN, "<br>")
        #print("characterFN1", keySpcharacterFN, "<br>")
        #print("<br>")
        if characterFN.islower():
            characterFN_mod += "<span class=redBG>"+characterFN+"</span>"
        elif characterFN == "X" or characterFN == "-":
            characterFN_mod += characterFN
        else:
            characterFN_mod += "<span class=blackBG>"+characterFN+"</span>"
    else:
        if characterFN == "X" or characterFN == "-":
            characterFN_mod += characterFN
        elif keySpcharacterFN.upper() == characterFN:
            characterFN_mod += "<span class=blackBG>"+characterFN+"</span>"
        else:
            characterFN_mod += characterFN

    return characterFN_mod

def recOneLinesMaker(keyNameFN, keySequenceFN, startPosNF, stopPosNF, recsFN):

    htmlOneLines = []

    longestName = max(recsFN.keys(), key = len)
    longestName = re.sub("<[^>]+>", "", longestName)
    #print("longestName", longestName)
    longestNameLen = len(longestName)
    #print("longestNameLen", longestNameLen)
    NumberLine = " " * (longestNameLen) + str(startPosNF+1) + "\n"
    htmlOneLines.append(NumberLine)

    #print("startPosNF", startPosNF)
    for name in recsFN.keys():
        nameLine = ""
        #if startPosNF == 0:
        #    htmlOneLine = link_genomeLocation(name)
        #else:
        #    htmlOneLine = name
        htmlOneLine = name

        for p in range(startPosNF, stopPosNF):
            character_keySpecies = keySequenceFN[p]
            character      = recsFN[name][p]
            character_HTML  = matchFirst_eachCharacter (keyNameFN, character_keySpecies, name, character)
            htmlOneLine += character_HTML
        
        keyNameFN_NS = re.sub("^>", "", keyNameFN)
        if re.search(keyNameFN_NS, name):
            htmlOneLine = "<u>" + htmlOneLine + "</u>"
                    
        
        htmlOneLine += "\n"
        htmlOneLines.append(htmlOneLine)

    return htmlOneLines

def interleavedMake(keyNameFN, keySequenceFN, oneLineLength, recsFN):
    #for name, seq in recsFN.items():
    #    print("name", name, "<br>")
    #exit()
    siteNum  = 1
    startPos = 0
    stopPos  = 0
    sequenceLengthFN = len(list(recsFN.values())[0])
    linesFN  = []
    for i in range(sequenceLengthFN):
        if i > 1 and i % oneLineLength == 0:
            startPos = i - oneLineLength
            stopPos = startPos + oneLineLength
            #print("siteNum :", startPos + 1)
            #print("startPos:", startPos)
            #print("stopPos :", stopPos)
            #for j in range(startPos, stopPos):
            #    print(str(j) + ",", end="")
            #print()
            recOneLines = recOneLinesMaker(keyNameFN, keySequenceFN, startPos, stopPos, recsFN)
            for line in recOneLines:
                linesFN.append(line)
            linesFN.append("\n")

    #print("siteNum :", stopPos + 1)
    #print("startPos:", stopPos)
    #print("stopPos :", sequenceLengthFN)
    #for i in range(stopPos, sequenceLengthFN):
    #    print(str(i) + ",", end="")
    #print()
    recOneLines = recOneLinesMaker(keyNameFN, keySequenceFN, stopPos, sequenceLengthFN, recsFN)
    for line in recOneLines:
        linesFN.append(line)
    linesFN.append("\n")
    return(linesFN)

def make_resHTMLfile(infile, outfile):
    oneLineLength = 90         ## For cDNA, needs to be a multiple of 3
    recs = readFasta_dict(infile)
    yourRecName, yourRecSequence = firstSpeciesPicker(recs)
    recs = addSiteNotes("130_trimedOut.html", recs)
    recs = whiteSpaceAdd(recs)
    #for name, sec in recs.items():
    #    print(name)
    #    print(sec)
    #exit()
    recs = addColor_nameline(recs, "../000_summary.txt")
    #for name, seq in recs.items():
    #    print(name)
    #exit()
    lines = interleavedMake(yourRecName, yourRecSequence, oneLineLength, recs)
    htmlFileMake(lines, yourRecSequence, outfile)

def modify_recs(recsFN):
    seqDictFN  = OrderedDict()
    for name, seq in recsFN.items():
        seq = re.sub("\r", "", seq)
        seqDictFN[name] = seq
    return seqDictFN

def count_blastHits(infile):
    recsFN = readFasta_dict(infile)
    recs_blastHitnum = OrderedDict()
    #print(recsFN.keys())
    #exit()

    species_colors = make_species_color("../000_summary.txt")

    for species_color in species_colors:
        speciesName = re.sub("_.*$", "_", species_color)
        countFN = 0
        for nameLine in recsFN.keys():
            #print("nameLine", nameLine)
            if nameLine.startswith(">YOURSEQ"):
                #print("continue")
                continue
            if re.search(speciesName, nameLine):
                countFN += 1
        recs_blastHitnum["D" + speciesName]=countFN
    recs_blastHitnum = whiteSpaceAdd(recs_blastHitnum)
    return recs_blastHitnum

def htmlFileMake(linesFN, keySequenceFN, outFileFN):
    #sequenceLength = len(keySequenceFN)
           
    #print("outFileFN", outFileFN)
    out = open(outFileFN, "w")

    #dirname_rand_TMP = dirname_rand
    #dirname_rand_TMP = re.sub("-.*$", "", dirname_rand_TMP)
    #top1 = re.sub("TITLE", dirname_rand_TMP, top)

    out.write(top)

    num_blastHits = count_blastHits(infile="120_mafOutFas.txt")
    num_blastHits = addColor_nameline(num_blastHits, "../000_summary.txt")

    out.write("# of blast hits:\n")
    for nameLine, value in num_blastHits.items():
        out.write(nameLine + ":" + str(value) + "\n")
    out.write("\n")

    out.write("Alignment of selected sequences:\n")

    #out.write(str(sequenceLength) + "\n")
    count0 = 0 
    count1 = 0 
    for line in linesFN:
        if line.startswith("Used4treeSearch"):
            count0tmp = line.count('0')
            count0 += count0tmp
            count1tmp = line.count('1')
            count1 += count1tmp
    out.write(str(count1) + " sites (1) were used for tree reconstruction by excluding " + str(count0)+ " sites (0).\n")

    out.write("speciesName_database_chr-start-end_geneName_bitScore\n")

    for line in linesFN:
        out.write(line)

    out.write(bottom)
    out.write("\n")
    out.close()

def addColor_nameline(recsFN1, summaryFile):
    species_color = make_species_color(summaryFile)
    #for ele in species_color:
    #    print(ele)
    #exit()
    recsFN2 = OrderedDict()
    for name_seq, seq in recsFN1.items():
        #print("A name_seq|", name_seq, "|")
        for name_color, color in species_color.items():
            if name_seq.startswith("YOURSEQ") or name_seq.startswith("Used4treeSearch"):
                recsFN2[name_seq] = seq
                break
            if name_seq.startswith(name_color):
                #print(name_seq + ":" + color + "<br>")
                color = color.rstrip("\n")
                match = re.search("^([^ ]+)( +)$", name_seq)
                content = match.group(1)
                space_after = match.group(2)
                #print("content|", content, "|")
                #print("space_after|", space_after, "|")
                #name_seq2 = "<font color=" + color + ">" + name_seq + "</font>"
                name_seq2 = "<font color=" + color + ">" + content + "</font>" + space_after
                recsFN2[name_seq2] = seq
                #print("B name_seq2|", name_seq2, "|")
                break
    return recsFN2

def trimAlresReader(inFileAAFN):
    aafile = open(inFileAAFN, "r")
    aafileLines = list(aafile)
    aafile.close()
    
    sequenceTMP = ""
    name_firstRec = ""
    for line in aafileLines:
        if re.search("    <span class=sel>[^<]+<", line):
            match = re.search("    <span class=sel>([^<]+)<", line)
            name_firstRec = match.group(1)
            break
    for line in aafileLines:
        if re.search("<span class=sel>" + name_firstRec + "<", line):
            line = re.sub("^ +<span class=sel>" + name_firstRec + "</span> +", "", line).rstrip("\n")
            line = re.sub("<span class=sel>.</span>", "#", line)
            sequenceTMP += line

    sequence = ""
    for chr in sequenceTMP:
        chr2 = ""
        if chr == "#":
            chr2 = "1"
        else:
            chr2 = "0"
        sequence += chr2

    if sequence:
        return sequence
    else:
        print("No key sequence line in :", inFileAAFN)
        exit()

#####################################################################################################################
#################################### Main program ####################################################################
######################################################################################################################



'''
'''


alignmentFile = "010_alignment.txt"

deleteGap_fasFile("../" + alignmentFile)
#fas2noGapfasFile("../" + alignmentFile)

maffLine1 = "mafft --preservecase 110_noGapFas.txt > 120_mafOutFas.txt"
#print("maffLine1", maffLine1)
subprocess.call(maffLine1, shell=True)
#exit()

trimLine1 = "trimal -out 130_trimedOutFas.txt -htmlout 130_trimedOut.html -in 120_mafOutFas.txt -gappyout"
###print("trimLine1:", trimLine1, "\n");
subprocess.call(trimLine1, shell=True)

fas2phy("120_mafOutFas.txt", outfile="200_alignment.txt")

trimaledPhyMake("130_trimedOutFas.txt")
fas2phy("130_trimedOutFas.txt", outfile="150_trimedPhy.txt")

outGroup = outGroupSelect("150_trimedPhy.txt")
treeEstimationLine = "Rscript 104_NJBSa.R 150_trimedPhy.txt " + outGroup + " TN93 200_NJtree.txt 200_branchLengths.txt"
#print("treeEstimationLine: ", treeEstimationLine)
subprocess.call(treeEstimationLine, shell=True)

outputTree = "200_NJTree.pdf"
treePlotR = "Rscript 105_treePlot.R " + "200_NJtree.txt " + outputTree
#print("treePlotR: ", treePlotR)
subprocess.call(treePlotR, shell=True)

make_resHTMLfile(infile = "120_mafOutFas.txt", outfile = "200_alignment.html")

remove_files2()


###print("### deleteFiles")


exit()
