library(ape)

args            <- commandArgs()
infile          <- args[6]
outGroup        <- args[7]
#outGroup        <- "SeaSquirt"
selectedModel   <- args[8]
outfile.nwk     <- args[9]
outFile_BL.txt  <- args[10]

confidence.interval <- 0.05
dell.value          <- NULL

#print ('  ## 104_NJBSa.R starts.')

#print('infile')
#print(infile)
#print("")
#print('outGroup')
#print(outGroup)
#print("")
#print('selectedModel')
#print(selectedModel)
#print("")
#print('outfile.nwk')
#print(outfile.nwk)
#print("")

#  print (paste('  infile', infile))

#outfile.nwk <- paste(outfile, '.nwk', sep = '')

## Open the 'infile' file
if(file.access(infile) != 0){
  print (paste(infile,' does not exist.'))
} else {
  infile.phy  <- read.dna(infile)
}


#################################################################################
############################## functions ##############################
SG <- function(x)       
{
    #print("x1")
    #print(x)
	while(TRUE)
	{
        branch.length <- range(x)
        x <- x[!is.na(x)]                   # 欠損値を除く
        n <- length(x)                      # 標本サイズ
        t <- abs(range(x)-mean(x))/sd(x)    # 最大のデータと最小のデータの両方について検定統計量を計算する
        #p <- n*pt(sqrt((n-2)/((n-1)^2/t^2/n-1)), n-2, lower.tail=FALSE) # P 値も2通り計算される
        p <- n*pt(sqrt((n-2)/((n-1)^2/t^2/n-1)), n-1, lower.tail=FALSE) # P 値も2通り計算される
        #print("p")
        #print(p)
        #result <- list(parameter=c(df=n-2))
        result <- list(parameter=c(df=n-1))
        #result1 <- structure(c(result,  list(branch.length=branch.length[1], statistic=c(t=t[1]), p.value=p[1])), class="htest")
        result2 <- structure(c(result,  list(branch.length=branch.length[2], statistic=c(t=t[2]), p.value=p[2])), class="htest")
        #print("result2")
        #print(result2)
        

        ### Maximum value
        if(result2$p.value < confidence.interval)
        {
          dell.value <- c(dell.value, result2$branch.length)
          x <- x[x!= result2$branch.length]
          next
        }
#        ### Minimum value
#        if(result1$p.value < confidence.interval)
#        {
#          dell.value <- c(dell.value, result1$branch.length)
#          x <- x[x!= result1$branch.length]
#          next
#        }
        else{
          return(list(x=x, dellVal = dell.value))
          break	
        }
      }
}

br.rootTip <- function(myTree)       
{

  myTree$node.label <- ((length(myTree$tip)+1):((length(myTree$tip)*2)-1))
  distRtoTs <- c()        # branch lengths from root to tip
  names     <- c()        # leaf names

  #for(i in 1:length(myTree$tip.label)-1)  #  -1 deletes the outgroup
  for(i in 1:length(myTree$tip.label))
  {
    
    #print("myTree$tip.label[i]")
    #print(myTree$tip.label[i])
    if (myTree$tip.label[i] == outGroup)
    {
        #print("OG")
        #print("myTree$tip.label[i]")
        #print(myTree$tip.label[i])
        next
    }
    #if (myTree$tip.label[i] == "YOURSEQ1_Human_HACNS1")
    #{
    #    print("OG")
    #    next
    #}
    #print("notOG")

    # Calculate the branch length and push distances into the vector, distRtoTs
    distRtoT  <- dist.nodes(myTree)[(length(myTree$tip)+2), i]

    # Change leaf names
  	#myTree$tip.label[i] <- paste(i,',',myTree$tip.label[i],':', distRtoT, sep="")
  	#myTree$tip.label[i] <- paste(myTree$tip.label[i],':', distRtoT, sep="")
  	
  	# Make the vectors of names and branch lengths
  	names <- c(names, myTree$tip.label[i])
    distRtoTs <- c(distRtoTs, distRtoT)
  }
  
  # Make the data frame [leaf, dist]
  Dfrm <- data.frame(NAMES = names, DIST = distRtoTs)

  # Return the dataframe and tree as list
  return( list(Dfrm=Dfrm, myTree=myTree))
}



#############################################################################
############################## Tree estimation ##############################
## Estimate distance
dist.selectedModel <- dist.dna(infile.phy, model = selectedModel, pairwise.deletion=TRUE, gamma=5)

## #Estimate NJ tree
nj.selectedModel <- njs(dist.selectedModel)

## Reroot by outGroup
nj.selectedModel <- root(nj.selectedModel,outGroup,r=T)

## ladderize from bottom
nj.selectedModel <- ladderize(nj.selectedModel,TRUE)

## BS analysis with partitioning data (1st+2nd)
#nj.boot.nj.selectedModel <- boot.phylo(nj.selectedModel, infile.phy,     function(xx) root(nj(dist.dna(xx, model = "selectedModel", pairwise.deletion = TRUE, gamma = 5)),outGroup,r=T), 100, 2)
#nj.boot.nj.selectedModel <- boot.phylo(nj.selectedModel, infile.phy,     function(xx) root(njs(dist.dna(xx, model = "selectedModel", pairwise.deletion = TRUE)), outGroup,r=T), 100, 2)
#nj.boot.nj.selectedModel <- boot.phylo(nj.selectedModel, infile.phy,     function(xx) root(njs(dist.dna(xx, model = selectedModel, pairwise.deletion = TRUE)), outGroup,r=T), 100)
#nj.selectedModel$node.label <- nj.boot.nj.selectedModel

## Change bs calues: NA -> 0
#for(p in 1:length(nj.selectedModel$node.label)){
#  print(p)
#  print(nj.selectedModel$node.label[p])
#}
#cat('\n\n')

#nj.selectedModel$node.label[is.na(nj.selectedModel$node.label)]<-0

#for(p in 1:length(nj.selectedModel$node.label)){
#  print(p)
#  print(nj.selectedModel$node.label[p])
#}
#cat('\n')




#################################################################################
############################## Get branch lengths (root-tip) ##############################
mytree <- nj.selectedModel

#mytree = read.tree(text = "(((((Stickleback:0.1,Fugu:0.75)68:0.1,Medaka:0.1)93:0.1,Zebrafish:1.85)90:0.1,((Chicken:0.1,Human:0.1)92:0.1,Xenopus:0.1)87:0.1)99:0.1,SeaSquirt:0.1)100;")
#outGroup <- "SeaSquirt"


#write.tree(mytree, file = "tree1.txt")
#mytree <- ladderize(mytree, FALSE)
#write.tree(mytree, file = "tree2.txt")


#print("mytree$tip")
#print(mytree$tip)

## Calculate the branch length from root to tip
#print("outGroup2")
#print(outGroup)
dfrmMyTree <- br.rootTip(mytree)
#print("dfrmMyTree")
#print(dfrmMyTree)
nameLengthDfrm <- dfrmMyTree$Dfrm
#print("nameLengthDfrm")
#print(nameLengthDfrm)


#################################################################################
############################## Smirnov-Grubbs test ##############################
#         myTree_SG         <- dfrmMyTree$myTree
#         
#         #print("nameLengthDfrm")
#         #print(nameLengthDfrm)
#         
#         # Smirnov-Grubbs test
#         resSG <- SG(nameLengthDfrm$DIST)    # Branch lengths of p < 0.05
#         #print("resSG")
#         #print(resSG)
#         
#         
#         ### Pick up the leaf names of long branches with p < 0.05
#         del.names <- NULL
#         
#         for(longBL in resSG$dellVal)
#         {
#             #print("longBL")
#             #print(longBL)
#         	for(p in 1: nrow(nameLengthDfrm))
#         	{
#         		if (nameLengthDfrm[p, 2] == longBL)
#         		{
#           		  del.names <- data.frame(rbind(del.names, nameLengthDfrm[p,]))
#         		}
#         	}
#         }
#         
#         #print("del.names$NAMES")
#         #print(del.names$NAMES)
#         #print("myTree_SG$tip.label")
#         #print(myTree_SG$tip.label)
#         ### Add * to the long branch leaves
#         for(spName in del.names$NAMES)
#         {
#         	for(z in 1: length(myTree_SG$tip.label))
#         	{
#         		leaf <- myTree_SG$tip.label[z]
#         		if (regexpr(spName, leaf) < 0) 
#         		{
#         		  next
#         		}
#            		myTree_SG$tip.label[z] <- paste(myTree_SG$tip.label[z],'*', sep = "")
#         		#cat(myTree_SG$tip.label[z],'\n')
#         	}
#         }

######################################################################
############################## Printout ##############################

##### Printout
## Write tree
#write.tree(myTree_SG, file = outfile.nwk)
write.tree(mytree, file = outfile.nwk)

#write.table(myTree$tip, file = outFile_BL.txt, quote = FALSE,row.names = FALSE,col.names = FALSE)
write.table(nameLengthDfrm, file = outFile_BL.txt, quote = FALSE,row.names = FALSE,col.names = FALSE)
#write.table(del.names, file = "200_longBranches11.txt", quote = FALSE,row.names = FALSE,col.names = FALSE)
