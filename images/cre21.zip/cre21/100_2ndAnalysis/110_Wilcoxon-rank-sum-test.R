#https://oku.edu.mie-u.ac.jp/~okumura/stat/wmw.html

## R --save <110_Wilcoxon-rank-sum-test.R >110_commandlog.txt

#install.packages("coin", repos="http://cran.ism.ac.jp/")
library(coin)


foreground_species <- c("Chrysochloris-asiatica", "Condylura-cristata", "Heterocephalus-glaber", "Nannospalax-galili")
#foreground_species <- c("Heterocephalus-glaber-male_0_JH173915.1-564650-564969_ENSHGLG00100010470_269")


##### function
line.picker <- function(foreground)
{
  container_foreground <- c()
  container_background <- c()
  for (species_name in foreground) {
      #print("species_name")
      #print(species_name)
      #print("")
      for(line in infile$V1) {
        #print(line)
        if (regexpr(species_name, line) > 0) {
            branch_length <- sub("^[^ ]+ ", "", line)
            container_foreground <- c(container_foreground, as.numeric(as.character(branch_length)))
        } else {
            branch_length <- sub("^[^ ]+ ", "", line)   
            container_background <- c(container_background, as.numeric(as.character(branch_length)))
        }
      }
  }
  return(list(foreground = container_foreground, background=container_background))
}

#####

infileName <- "200_branchLengths.txt"
infile    <- read.table(infileName, na.strings = FALSE, sep = '\t')
#print("infile")
#print(infile)
#stop("Nes")

foreground_background <- line.picker(foreground_species)
foreground <- foreground_background$foreground
background <- foreground_background$background

print("foreground")
print(foreground)
print("background")
print(background)
#stop("Message")


### https://data-science.gr.jp/implementation/ist_r_wilcoxon_rank_sum_test.html
#x = c(1.83, 1.50, 1.62, 2.48, 1.68, 1.88, 1.55, 3.06, 1.30, 2.01, 3.11)
#y = c(0.88, 0.65, 0.60, 1.05, 1.06, 1.29, 1.06, 2.14, 1.29)
#
#result <- wilcox_test(c(x,y) ~ factor(c(rep("x",length(x)),rep("y",length(y)))),
#            distribution="exact")

#print(x)
#print(foreground)
#stop("Message")

result <- wilcox_test(c(foreground, background) ~ factor(c(rep("foreground",length(foreground)),rep("background",length(background)))),
            distribution="exact")

print(result)